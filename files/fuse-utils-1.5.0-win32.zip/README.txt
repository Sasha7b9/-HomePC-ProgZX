The Fuse utilities version 1.5.0
================================

The Fuse utilities are a few tools which may be of occasional use when
dealing with ZX Spectrum emulator files. They were originally
distributed with Fuse, the Free Unix Spectrum Emulator, but are now
independent of Fuse and can be used on their own.

The available utilities are:

* audio2tape: convert an audio file to tape format.
* createhdf: create an empty .hdf IDE hard disk image.
* fmfconv: converter tool for FMF movie files.
* listbasic: list the BASIC in a snapshot, tape or Microdrive cartridge file.
* mdrlist: list the contents of an MDR Microdrive cartridge image.
* profile2map: convert Fuse profiler output to Z80-style map format.
* raw2hdf: create a .hdf IDE hard disk image from another file.
* rzxcheck: verify the digital signature in an RZX file.
* rzxdump: list the contents of an RZX input recording file.
* rzxtool: add, extract or remove the embedded snapshot from an RZX file,
           or compress or uncompress the file.
* scl2trd: convert .scl disk images to .trd disk images.
* snap2tzx: convert snapshots to TZX tape images.
* snapconv: convert between snapshot formats.
* snapdump: list information about machine status stored in a snapshot file.
* tape2pulses: dumps the pulse information from tape images to text files.
* tape2wav: convert a tape file to .wav audio format.
* tapeconv: convert between .tzx and .tap files.
* tzxlist: list the contents of a TZX, TAP, PZX or Warajevo TAP file.

In order to use the utilities, you'll need `libspectrum' installed;
this is available from:

http://fuse-emulator.sourceforge.net/libspectrum.php

If you want to deal with compressed RZX files, you'll also need `zlib'
installed.

Once you've got any libraries installed, building the utilities should
be as simple as:

$ ./configure
$ make

and then

$ make install

By default, the utilities will be installed in `/usr/local', so you'll
probably have to be root to do the last step. If you want to change
this, give the `--prefix=DIR' option to `configure' to install them
under `DIR'.

The latest version of the utilities should always be available from
http://fuse-emulator.sourceforge.net/fuse.php

If you're having a problem using/running/building fuse-utils, the two places
you're most likely to get help are the development mailing list
<fuse-emulator-devel@lists.sf.net> or the official forums at
<https://sourceforge.net/p/fuse-emulator/discussion/>.

Compiling from Git
------------------

If you're using version of fuse-utils from Git rather than one
of the released tarballs, you'll need to run `autogen.sh' before
running 'configure' for the first time.

Maintainer release notes are in `hacking/releasing.md'.

Philip Kendall <philip-fuse@shadowmagic.org.uk>
20th September, 2026
